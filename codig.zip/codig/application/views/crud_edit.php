
	
		<?php
			
		foreach($result_set as $result) {?>
			<?php $bases = base_url();?>
			<form method="post" action="<?=base_url()."index.php/Crud/update";?>">
				<input type="hidden" value="<?php echo $result['id']; ?>">
				<div class="row">
					<div class="col-lg-4">Employee Name</div>
					<div class="col-lg-8">
						<input type="text" required value="<?php echo $result['emp_name']; ?>" class="form-control" name="emp_name">
					</div>
				</div><br>
				<div class="row">	
					<div class="col-lg-4">Email Id</div>
					<div class="col-lg-8"><input required 
					value="<?php echo $result['email_id']; ?>"  class="form-control"
					type="email" name="email_id"></div><br>
				</div><br>
				<div class="row">	
					<div class="col-lg-4">Phone Number</div>
					<div class="col-lg-8"><input required value="<?php echo $result['phone_number']; ?>"  class="form-control" type="number" name="phone_number"></div><br>
				</div><br>
				<div class="row">
					<div class="col-lg-4">Date Of Birth</div>
					<div class="col-lg-8"><input value="<?php echo $result['dob']; ?>" readonly required class="form-control" id="date" name="dob" placeholder="DD/MM/YYY" type="text"/></div>
				</div>
				<br>
				<input type="submit">
				<input type="reset">
			</form>	
		
		<?php } ?>