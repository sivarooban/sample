<?php

class Crud1 extends CI_Model {
    public function __construct() {
//        parent::__construct();
        $this->load->database('default');
        //$this->load->helper(array('date', 'cookie', 'url'));
    }
    public function cruddetail() {       
        $this->db->select("id,emp_name,email_id,phone_number,dob");
        $this->db->from('crud1');        
        $query = $this->db->get();
        //echo $this->db->last_query();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }
    }   
	public function cruddetail_delete($id) {       
        $this->db->where('id', $id);
        $del = $this->db->delete('crud1');
        return $del;
    } 
	public function cruddetail_insert($form_data) {              
        return $this->db->insert('crud1',$form_data);
		
    } 
	public function cruddetail_check_email($email_id) {
		$this->db->select('email_id');
		$this->db->where('email_id', $email_id);
		$result = $this->db->get('crud1');
		//echo $result->num_rows();
		return $result->num_rows();
						
    } 
    public function cruddetail_check_phone($phone_number) {              
        $this->db->select('phone_number');
		$this->db->where('phone_number', $phone_number);
		$result = $this->db->get('crud1');
		return $result->num_rows();
    } 
	public function cruddetail_getrecord($id) {              
        $this->db->select('*');
		$this->db->from('crud1');  
		$this->db->where('id', $id);		      
        $query = $this->db->get();
		//echo $this->db->last_query();
		if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return FALSE;
        }		
    } 
}
